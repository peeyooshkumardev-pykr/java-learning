// Q14 — Print a Pascal's Triangle
// Take an integer N and print Pascal's triangle.
//aaaa1
//   1 1
//  1 2 1
// 1 3 3 1
//1 4 6 4 1
import java.util.Scanner;

public class Q14_PrintAPascalsTriangle {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        System.out.print("Enter the integer = ");
        int N = sc.nextInt();

        for(int i = 1; i<=N; i++){

            for(int j = i; j<=N-1; j++){
                System.out.print(" ");
            }

            for(int j = i; j<=N; j++){
                if(i + j == N + 1){
                    System.out.print("1");
                }
            }
            for(int j = i; j<=N-1; j++){
                if(j - i == N - 1){
                    System.out.print("1");
                }
            }

            System.out.println();
        }    
        sc.close();
    }
}
